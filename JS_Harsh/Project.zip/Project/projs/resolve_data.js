var arr_email = ['Admin@gmail.com'];
var arr_pass = ['Admin@1999'];

function setData () {

	if (localStorage.clickcount) {
      localStorage.clickcount = Number(localStorage.clickcount)+1;
    } else {
      localStorage.clickcount = 0;
    }

	var user = new Object();
		
	let name = document.getElementById('res_fullname').value;
	let email = document.getElementById('res_email').value;
	let pass = document.getElementById('pass_login').value;
	localStorage.setItem('id', localStorage.clickcount);
	user.id = localStorage.getItem('id');


	
	user.name = name;
	user.email = email;
	user.pass = pass;
	//localStorage.setItem('id', value: DOMString)
	
	localStorage.setItem('kname' + user.id, name);
	localStorage.setItem('kemail' + user.id, email);
	localStorage.setItem('kpass' + user.id,  pass);
	localStorage.setItem('kindex'+ user.id, user.id);

	arr_email.push(localStorage.getItem('kemail' + user.id));
	arr_pass.push(localStorage.getItem('kpass' + user.id));
	
}

function similarEmail () {
	// body... 
	let email = document.getElementById('res_email').value;
	for(let m = 0; m < localStorage.length; m++)
	{
		if (email == localStorage.getItem('kemail' +  m)){
			document.getElementById('error_email').style.display = 'block';
			document.getElementById('error_email').innerHTML = "Email has existed! Please change other email.";
			document.getElementById('res_email').value = "";
			
		}
		else
		{
			continue;
		}
		
	}
}

let res = "";
function checkLogin() {
	var x = document.getElementById('email_login').value;
	var y = document.getElementById('pass_login').value;
	for(let i = 0; i < localStorage.length; i++)
	{
		if(x == localStorage.getItem('kemail' + i) && y == localStorage.getItem('kpass'+i))
		{
			alert("right");
			document.getElementById('frmlogin').action= "./login_success.html";

			res = localStorage.getItem("kname"+i) + "";
			localStorage.setItem('key', i);
			localStorage.setItem('userpass', localStorage.getItem('kpass'+i));
			localStorage.setItem('user', res);
			localStorage.setItem('useremail', localStorage.getItem('kemail'+i));
			break;
		}
		else {
			continue;	
		}
	}
	if(x == "Admin@gmail.com" && y == "Admin@999")
	{
		document.getElementById('frmlogin').action= "./admin.html";
	} 


}
try {
	// statements
	document.getElementById('result_user').innerHTML = localStorage.getItem('user');

} catch(e) {
	// statements
	console.log(e);
}
function showData () {
	// body... 
	document.getElementById('email_edt').value = localStorage.getItem('useremail');
	document.getElementById('pass_edt').value = localStorage.getItem('userpass');
}

function editData()
{
	
	var old_pass = localStorage.getItem('userpass');
	var old_email = localStorage.getItem('useremail');
	
	var k = localStorage.getItem('key');
	
	var edt_email = document.getElementById('email_edt').value;
	var edt_pass = document.getElementById('pass_edt').value;
	alert(edt_email + edt_pass);
	localStorage.setItem('userpass', "");
	localStorage.setItem('useremail', "");

	localStorage.setItem('kpass' + k, edt_pass);
	localStorage.setItem('kemail' + k, edt_email);
}
//Get name of user when login success

function deleteUser () {
	// body... 
	var t = prompt("Input user you want to delete(index)", '');
	alert(t);
	localStorage.removeItem('kemail' + t);
	localStorage.removeItem('kpass' + t);
	localStorage.removeItem('kname' + t);
	location.reload();
	//localStorage.setItem('id', localStorage.clickcount--);
}
function showDataAdmin () {
	// body... 
	document.getElementById('email_edt').value = localStorage.getItem('useremail');
	document.getElementById('pass_edt').value = localStorage.getItem('userpass');
}